package com.alexic0n.filmstercatalogueapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilmsterCatalogueApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
