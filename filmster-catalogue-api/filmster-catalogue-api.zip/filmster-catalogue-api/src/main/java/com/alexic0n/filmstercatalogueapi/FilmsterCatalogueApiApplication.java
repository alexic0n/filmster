package com.alexic0n.filmstercatalogueapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FilmsterCatalogueApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FilmsterCatalogueApiApplication.class, args);
	}

}
